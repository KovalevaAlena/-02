﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Text_Redactor
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            string AssemblyProduct = "Текстовый редактор",
                   AssemblyVersion = "1.1.1",
                   AssemblyCompany = "MyCompany";
           // this.Text = String.Format("О {0}", AssemblyTitle);
            this.labelProductName.Text = AssemblyProduct;
            this.labelVersion.Text = String.Format("Версия {0}", AssemblyVersion);
            this.labelCopyright.Text = "Ковалёва А. А."; // AssemblyCopyright;
            this.labelCompanyName.Text = AssemblyCompany;
            this.textBoxDescription.Text = "\n Текстовой редактор"; //AssemblyDescription;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
