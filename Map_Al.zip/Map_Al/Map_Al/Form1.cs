﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Map_Al
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Ch1_Click(object sender, EventArgs e)
        {
            punkt.Text = "Пункт 1";
            dost.Text = "Рынок";
            drinks.Visible = true; drinkst.Visible = true;
            energi.Visible = true; energit.Visible = true;
            info.Visible = false; infot.Visible = false;
            med.Visible = false; medt.Visible = false;
            tualet.Visible = false; tualett.Visible = false;


        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }

        private void Ch2_Click(object sender, EventArgs e)
        {
            punkt.Text = "Пункт 2";
            dost.Text = "Площадь";
            drinks.Visible = true; drinkst.Visible = true;
            energi.Visible = true; energit.Visible = true;
            info.Visible = true; infot.Visible = true;
            med.Visible = true; medt.Visible = true;
            tualet.Visible = true; tualett.Visible = true;
        }

        private void Ch3_Click(object sender, EventArgs e)
        {
            punkt.Text = "Пункт 3";
            dost.Text = "Твоя попка";
            drinks.Visible = true; drinkst.Visible = true;
            energi.Visible = true; energit.Visible = true;
            info.Visible = true; infot.Visible = true;
            med.Visible = false; medt.Visible = false;
            tualet.Visible = false; tualett.Visible = false;
        }

        private void Ch4_Click(object sender, EventArgs e)
        {
            punkt.Text = "Пункт 4";
            dost.Text = "Сладкая моя";
            drinks.Visible = true; drinkst.Visible = true;
            energi.Visible = true; energit.Visible = true;
            info.Visible = true; infot.Visible = true;
            med.Visible = false; medt.Visible = false;
            tualet.Visible = true; tualett.Visible = true;
        }

        private void Ch5_Click(object sender, EventArgs e)
        {
            punkt.Text = "Пункт 5";
            dost.Text = "ffff";
            drinks.Visible = true; drinkst.Visible = true;
            energi.Visible = true; energit.Visible = true;
            info.Visible = true; infot.Visible = true;
            med.Visible = true; medt.Visible = true;
            tualet.Visible = false; tualett.Visible = false;
        }

        private void Ch6_Click(object sender, EventArgs e)
        {
            punkt.Text = "Пункт 6";
            dost.Text = "Августин";
            drinks.Visible = true; drinkst.Visible = true;
            energi.Visible = true; energit.Visible = true;
            info.Visible = true; infot.Visible = true;
            med.Visible = false; medt.Visible = false;
            tualet.Visible = false; tualett.Visible = false;
        }

        private void Ch7_Click(object sender, EventArgs e)
        {
            punkt.Text = "Пункт 7";
            dost.Text = "вваааа";
            drinks.Visible = true; drinkst.Visible = true;
            energi.Visible = true; energit.Visible = true;
            info.Visible = true; infot.Visible = true;
            med.Visible = true; medt.Visible = true;
            tualet.Visible = true; tualett.Visible = true;
        }

        private void Ch8_Click(object sender, EventArgs e)
        {
            punkt.Text = "Пункт 8";
            dost.Text = "ввв";
            drinks.Visible = true; drinkst.Visible = true;
            energi.Visible = true; energit.Visible = true;
            info.Visible = true; infot.Visible = true;
            med.Visible = true; medt.Visible = true;
            tualet.Visible = true; tualett.Visible = true;
        }
    }
    
}
