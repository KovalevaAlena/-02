﻿namespace Map_Al
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.punkt = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Finish = new System.Windows.Forms.PictureBox();
            this.Ch8 = new System.Windows.Forms.PictureBox();
            this.Ch7 = new System.Windows.Forms.PictureBox();
            this.Ch6 = new System.Windows.Forms.PictureBox();
            this.Ch5 = new System.Windows.Forms.PictureBox();
            this.Ch4 = new System.Windows.Forms.PictureBox();
            this.Ch3 = new System.Windows.Forms.PictureBox();
            this.Ch2 = new System.Windows.Forms.PictureBox();
            this.Ch1 = new System.Windows.Forms.PictureBox();
            this.my_map = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Finish)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.my_map)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Location = new System.Drawing.Point(458, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(330, 393);
            this.label1.TabIndex = 13;
            // 
            // punkt
            // 
            this.punkt.BackColor = System.Drawing.SystemColors.Control;
            this.punkt.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.punkt.Location = new System.Drawing.Point(575, 34);
            this.punkt.Name = "punkt";
            this.punkt.Size = new System.Drawing.Size(106, 32);
            this.punkt.TabIndex = 14;
            this.punkt.Text = "Пункт 1";
            this.punkt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.punkt.Click += new System.EventHandler(this.label2_Click);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(469, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 15;
            this.label2.Text = "label2";
            this.label2.Click += new System.EventHandler(this.label2_Click_1);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.Control;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(468, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(220, 32);
            this.label3.TabIndex = 16;
            this.label3.Text = "Достопримечательность:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(469, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(161, 25);
            this.label4.TabIndex = 17;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.Control;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(468, 123);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(141, 28);
            this.label5.TabIndex = 18;
            this.label5.Text = "Сервис:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Map_Al.Properties.Resources.map_icon_drinks;
            this.pictureBox5.Location = new System.Drawing.Point(472, 154);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(48, 47);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 20;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Map_Al.Properties.Resources.krestik;
            this.pictureBox4.Location = new System.Drawing.Point(744, 34);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(35, 32);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 19;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Map_Al.Properties.Resources.map_icon_start;
            this.pictureBox3.Location = new System.Drawing.Point(99, 281);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(44, 45);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 12;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Map_Al.Properties.Resources.map_icon_start;
            this.pictureBox2.Location = new System.Drawing.Point(348, 252);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 45);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 11;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Map_Al.Properties.Resources.map_icon_start;
            this.pictureBox1.Location = new System.Drawing.Point(160, 41);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(45, 45);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // Finish
            // 
            this.Finish.Image = global::Map_Al.Properties.Resources.finish;
            this.Finish.Location = new System.Drawing.Point(126, 41);
            this.Finish.Name = "Finish";
            this.Finish.Size = new System.Drawing.Size(28, 64);
            this.Finish.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Finish.TabIndex = 9;
            this.Finish.TabStop = false;
            // 
            // Ch8
            // 
            this.Ch8.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Ch8.Image = global::Map_Al.Properties.Resources._8;
            this.Ch8.Location = new System.Drawing.Point(37, 159);
            this.Ch8.Name = "Ch8";
            this.Ch8.Size = new System.Drawing.Size(42, 37);
            this.Ch8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Ch8.TabIndex = 8;
            this.Ch8.TabStop = false;
            // 
            // Ch7
            // 
            this.Ch7.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Ch7.Image = global::Map_Al.Properties.Resources._7;
            this.Ch7.Location = new System.Drawing.Point(51, 260);
            this.Ch7.Name = "Ch7";
            this.Ch7.Size = new System.Drawing.Size(42, 37);
            this.Ch7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Ch7.TabIndex = 7;
            this.Ch7.TabStop = false;
            // 
            // Ch6
            // 
            this.Ch6.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Ch6.Image = global::Map_Al.Properties.Resources._6;
            this.Ch6.Location = new System.Drawing.Point(87, 332);
            this.Ch6.Name = "Ch6";
            this.Ch6.Size = new System.Drawing.Size(42, 37);
            this.Ch6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Ch6.TabIndex = 6;
            this.Ch6.TabStop = false;
            // 
            // Ch5
            // 
            this.Ch5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Ch5.Image = global::Map_Al.Properties.Resources._5;
            this.Ch5.Location = new System.Drawing.Point(213, 371);
            this.Ch5.Name = "Ch5";
            this.Ch5.Size = new System.Drawing.Size(42, 37);
            this.Ch5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Ch5.TabIndex = 5;
            this.Ch5.TabStop = false;
            // 
            // Ch4
            // 
            this.Ch4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Ch4.Image = global::Map_Al.Properties.Resources._4;
            this.Ch4.Location = new System.Drawing.Point(366, 318);
            this.Ch4.Name = "Ch4";
            this.Ch4.Size = new System.Drawing.Size(42, 37);
            this.Ch4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Ch4.TabIndex = 4;
            this.Ch4.TabStop = false;
            // 
            // Ch3
            // 
            this.Ch3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Ch3.Image = global::Map_Al.Properties.Resources._3;
            this.Ch3.Location = new System.Drawing.Point(272, 229);
            this.Ch3.Name = "Ch3";
            this.Ch3.Size = new System.Drawing.Size(42, 37);
            this.Ch3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Ch3.TabIndex = 3;
            this.Ch3.TabStop = false;
            // 
            // Ch2
            // 
            this.Ch2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Ch2.Image = global::Map_Al.Properties.Resources._2;
            this.Ch2.Location = new System.Drawing.Point(272, 150);
            this.Ch2.Name = "Ch2";
            this.Ch2.Size = new System.Drawing.Size(42, 37);
            this.Ch2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Ch2.TabIndex = 2;
            this.Ch2.TabStop = false;
            // 
            // Ch1
            // 
            this.Ch1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Ch1.Image = global::Map_Al.Properties.Resources._1;
            this.Ch1.Location = new System.Drawing.Point(244, 29);
            this.Ch1.Name = "Ch1";
            this.Ch1.Size = new System.Drawing.Size(42, 37);
            this.Ch1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Ch1.TabIndex = 1;
            this.Ch1.TabStop = false;
            this.Ch1.Click += new System.EventHandler(this.Ch1_Click);
            // 
            // my_map
            // 
            this.my_map.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.my_map.Image = global::Map_Al.Properties.Resources.map;
            this.my_map.Location = new System.Drawing.Point(13, 29);
            this.my_map.Name = "my_map";
            this.my_map.Size = new System.Drawing.Size(395, 393);
            this.my_map.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.my_map.TabIndex = 0;
            this.my_map.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Map_Al.Properties.Resources.map_icon_energy_bars;
            this.pictureBox6.Location = new System.Drawing.Point(472, 207);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(48, 47);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 21;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::Map_Al.Properties.Resources.map_icon_information;
            this.pictureBox7.Location = new System.Drawing.Point(472, 260);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(48, 47);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 22;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Click += new System.EventHandler(this.pictureBox7_Click);
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::Map_Al.Properties.Resources.map_icon_medical;
            this.pictureBox8.Location = new System.Drawing.Point(472, 313);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(48, 47);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 23;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Click += new System.EventHandler(this.pictureBox8_Click);
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::Map_Al.Properties.Resources.map_icon_toilets;
            this.pictureBox9.Location = new System.Drawing.Point(472, 366);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(48, 47);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 24;
            this.pictureBox9.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.punkt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Finish);
            this.Controls.Add(this.Ch8);
            this.Controls.Add(this.Ch7);
            this.Controls.Add(this.Ch6);
            this.Controls.Add(this.Ch5);
            this.Controls.Add(this.Ch4);
            this.Controls.Add(this.Ch3);
            this.Controls.Add(this.Ch2);
            this.Controls.Add(this.Ch1);
            this.Controls.Add(this.my_map);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Finish)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.my_map)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox my_map;
        private System.Windows.Forms.PictureBox Ch1;
        private System.Windows.Forms.PictureBox Ch2;
        private System.Windows.Forms.PictureBox Ch3;
        private System.Windows.Forms.PictureBox Ch4;
        private System.Windows.Forms.PictureBox Ch5;
        private System.Windows.Forms.PictureBox Ch6;
        private System.Windows.Forms.PictureBox Ch7;
        private System.Windows.Forms.PictureBox Ch8;
        private System.Windows.Forms.PictureBox Finish;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label punkt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
    }
}

