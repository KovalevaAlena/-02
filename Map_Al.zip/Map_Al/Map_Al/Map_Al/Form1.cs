﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Map_Al
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Ch1_Click(object sender, EventArgs e)
        {
            punkt.Text = "Пункт 1";
            dost.Text = "Тауэрский мост";
            drinks.Visible = true; drinkst.Visible = true;
            energi.Visible = true; energit.Visible = true;
            info.Visible = false; infot.Visible = false;
            med.Visible = false; medt.Visible = false;
            tualet.Visible = false; tualett.Visible = false;
            label5.Visible = true;
            label3.Visible = true;


        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }

        private void Ch2_Click(object sender, EventArgs e)
        {
            punkt.Text = "Пункт 2";
            dost.Text = "Букингемский дворец";
            drinks.Visible = true; drinkst.Visible = true;
            energi.Visible = true; energit.Visible = true;
            info.Visible = true; infot.Visible = true;
            med.Visible = true; medt.Visible = true;
            tualet.Visible = true; tualett.Visible = true;
            label5.Visible = true; label3.Visible = true;
        }

        private void Ch3_Click(object sender, EventArgs e)
        {
            punkt.Text = "Пункт 3";
            dost.Text = "Тауэр";
            drinks.Visible = true; drinkst.Visible = true;
            energi.Visible = true; energit.Visible = true;
            info.Visible = true; infot.Visible = true;
            med.Visible = false; medt.Visible = false;
            tualet.Visible = false; tualett.Visible = false;
            label5.Visible = true; label3.Visible = true;
        }

        private void Ch4_Click(object sender, EventArgs e)
        {
            punkt.Text = "Пункт 4";
            dost.Text = "Лондонский глаз";
            drinks.Visible = true; drinkst.Visible = true;
            energi.Visible = true; energit.Visible = true;
            info.Visible = true; infot.Visible = true;
            med.Visible = false; medt.Visible = false;
            tualet.Visible = true; tualett.Visible = true;
            label5.Visible = true; label3.Visible = true;
        }

        private void Ch5_Click(object sender, EventArgs e)
        {
            punkt.Text = "Пункт 5";
            dost.Text = "Британский музей";
            drinks.Visible = true; drinkst.Visible = true;
            energi.Visible = true; energit.Visible = true;
            info.Visible = true; infot.Visible = true;
            med.Visible = true; medt.Visible = true;
            tualet.Visible = false; tualett.Visible = false;
            label5.Visible = true; label3.Visible = true;
        }

        private void Ch6_Click(object sender, EventArgs e)
        {
            punkt.Text = "Пункт 6";
            dost.Text = "Биг-Бен";
            drinks.Visible = true; drinkst.Visible = true;
            energi.Visible = true; energit.Visible = true;
            info.Visible = true; infot.Visible = true;
            med.Visible = false; medt.Visible = false;
            tualet.Visible = false; tualett.Visible = false;
            label5.Visible = true; label3.Visible = true;
        }

        private void Ch7_Click(object sender, EventArgs e)
        {
            punkt.Text = "Пункт 7";
            dost.Text = "Собор Святого Павла";
            drinks.Visible = true; drinkst.Visible = true;
            energi.Visible = true; energit.Visible = true;
            info.Visible = true; infot.Visible = true;
            med.Visible = true; medt.Visible = true;
            tualet.Visible = true; tualett.Visible = true;
            label5.Visible = true; label3.Visible = true;
        }

        private void Ch8_Click(object sender, EventArgs e)
        {
            punkt.Text = "Пункт 8";
            dost.Text = "Вестминстерское аббатство";
            drinks.Visible = true; drinkst.Visible = true;
            energi.Visible = true; energit.Visible = true;
            info.Visible = true; infot.Visible = true;
            med.Visible = true; medt.Visible = true;
            tualet.Visible = true; tualett.Visible = true;
            label5.Visible = true; label3.Visible = true;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            punkt.Text = "Начало марафона";
            dost.Text = "Марафон по Лондону";
            drinks.Visible = false; drinkst.Visible = false;
            energi.Visible = false; energit.Visible = false;
            info.Visible = false; infot.Visible = false;
            med.Visible = false; medt.Visible = false;
            tualet.Visible = false; tualett.Visible = false;
            label3.Visible = false;
            label5.Visible = false;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            punkt.Text = "Продолжение марафона";
            dost.Text = "Музей Виктории и Альберта";
            drinks.Visible = false; drinkst.Visible = false;
            energi.Visible = false; energit.Visible = false;
            info.Visible = false; infot.Visible = false;
            med.Visible = false; medt.Visible = false;
            tualet.Visible = false; tualett.Visible = false;
            label3.Visible = false;
            label5.Visible = false;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            punkt.Text = "Конец марафона";
            dost.Text = "Музей мадам Тюссо";
            drinks.Visible = false; drinkst.Visible = false;
            energi.Visible = false; energit.Visible = false;
            info.Visible = false; infot.Visible = false;
            med.Visible = false; medt.Visible = false;
            tualet.Visible = false; tualett.Visible = false;
            label3.Visible = false;
            label5.Visible = false;
        }
    }
    
}
