﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pract01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double otvet = Math.Round(26 / ((((34.06 - 33.81) * 4) / (6.84 / (Math.Pow((28.57 - 25.15), (1.0 / 5.0))))) - (Math.Sqrt((3 + (4.2 / 0.1)) / ((1 / 0.3 - 2.7) / 4.12)))) + (2.0 / 3.0) / (4.0 / 21.0) + Math.Pow(((1 + Math.Pow(5, (1.0 / 3.0))) / 3.5), (1.0 / 4.0)), 5);
            Console.Write("Ответ, с присвоением значения всего выражения одной переменной: ");
            Console.WriteLine(otvet);

            double deistv1 = ((34.06 - 33.81) * 4) / (6.84 / (Math.Pow((28.57 - 25.15), (1.0 / 5.0))));
            double deistv2 = Math.Sqrt((3 + (4.2 / 0.1)) / ((1 / 0.3 - 2.7) / 4.12));
            double deistv3 = deistv1 - deistv2;
            double deistv4 = 26 / deistv3;
            double deistv5 = (2.0 / 3.0) / (4.0 / 21.0);
            double deistv6 = Math.Pow(((1 + Math.Pow(5, (1.0 / 3.0))) / 3.5), (1.0 / 4.0));
            double deistv7 = Math.Round((deistv4 + deistv5 + deistv6), 5);

            Console.Write("Ответ, с разбиением на упрощенные выражения: ");
            Console.WriteLine(deistv7);

            Console.ReadKey();
        }
    }
}
