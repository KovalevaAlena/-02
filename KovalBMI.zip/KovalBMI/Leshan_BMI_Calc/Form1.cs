﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KovalBMI
{
    public partial class Form1 : Form
    { 
        public Form1()
        {
            InitializeComponent();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void button_raschet_Click(object sender, EventArgs e)
        {
            double rost = Convert.ToInt32(textBox_rost.Text)/100;
            double ves = Convert.ToInt32(textBox_ves.Text);
            double index = Math.Round((ves / (rost * rost)), 1);
            label_ind.Text = index.ToString();
            if (index < 10)
                trackBar1.Value = 10; label_vivod.Text = "Недостаточный вес";
            //if (index < 18.5 && index >= 10)
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {

        }

        private void label8_Click_1(object sender, EventArgs e)
        {

        }
    }
}
